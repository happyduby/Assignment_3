<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title></title>
</head>
<style type="text/css">

    table{
        width: 1200px;
        margin: auto;
        text-align: center;
        table-layout: fixed;
    }
    table,tr, th,td{
        padding: 7px;
        color:white;
        border:4px solid black;
        font-size: 13px;
        border-collapse: collapse;
        font-family: arial;
        background:palevioletred;
    }
    td:hover{
        background:orange;
    }
</style>
<body>
<?php

require ("connection.php");

$roll=$_SESSION['roll'];

// the below code gets date from php
$date = explode('-', date("Y-m-d"));
$year = $date[0];
$month = $date[1];
if((int)$month < 6)
{
    // example
    // here if month is less than june and current year is 2020, academic_year will be 2019-20
    $old_year = $year-1;
    $academic_year = $old_year."-".$year;
}else{
    // example
    // here if month is greater than or equal to june and current year is 2020, academic_year will be 2020-21
    $new_year = $year+1;
    $academic_year = $year."-".$new_year;
}

// this query will group attendance by month for that academic_year and roll_no.
// ROLLUP in this query will give the total present and absent for that whole year. This will be the last row

$query = "SELECT year,monthname(str_to_date(month,'%m')) as monthname,SUM(present = 'yes') as present,SUM(present = 'no') as absent FROM attendance_track WHERE rollno='$roll' AND academic_year='$academic_year' GROUP BY month WITH ROLLUP";

$result = mysqli_query( $connection,$query)or die ("Error in query: ".$query. " ".mysqli_error($connection));


echo "<br><BR><table><tr><th>Year</th><th>Month</th><th>Roll No</th><th>Total</th><th>No of Days Present</th><th>No of Days Absent</th></tr>";
if (mysqli_num_rows($result) > 0) {
    while($row= mysqli_fetch_array($result)) {

        // the below if condition is for the Rollup(Total row) clause which does not contain monthname
        if(!empty($row["monthname"])) {
            $total = $row['present'] + $row['absent'];

            echo "<tr>" .
                "<td>" . $row['year'] .
                "<td>" . $row['monthname'] .
                "<td>" . $_SESSION['roll'] .
                "<td>" . $total .
                "</td><td> " . $row['present'] .

                "</td><td> " . $row['absent'] .
                "</td>
                </tr>";
        }else
        {
           break;
        }


    }
}

echo "</table>";

echo "<br><BR><table><tr><th>Academic Year</th><th>Total</th><th>No of Days Present</th><th>No of Days Absent</th></tr>";
// this is the rollup (or total row)
if(isset($row) ) {
    $total = $row['present'] + $row['absent'];
    echo "<tr>" .
        "<td>" . $academic_year .
        "<td>" . $total .
        "</td><td> " . $row['present'] .

        "</td><td> " . $row['absent'] .
        "</td>
     </tr>";
}
echo "</table>";

mysqli_free_result($result);
mysqli_close($connection);





?>
</body>
</html>




