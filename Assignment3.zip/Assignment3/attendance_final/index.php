<?php
	include "connection.php";
	session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<title>e-Care School</title>
		<link rel="stylesheet" type="text/css" href="style.css">
                <style>
                    html{
                        
                    background:linear-gradient(to bottom right,skyblue,violet,skyblue);}
                </style>
                   
	</head>
	<body class="back">
          
		<?php include"navbar.php";?>
            <img src="13.jpg" width="800" height="400">
                <br><br>
        <center>   <a href="home.php"><img id="s1" src="1.jpg" height="30%" width="30%" > </a><BR> <font color="black" size="5">Student Security And Academics</font><br><br>
         </center>
		
				
			</div>
		</div>
		
		<?php include"footer.php";?>
		
	
		
	</body>
</html>