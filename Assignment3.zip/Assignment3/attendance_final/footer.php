<script>

	var smsbutton = document.getElementById("sms");

	if(smsbutton) {
		smsbutton.addEventListener("click", function () {

			console.log("attendance ");

			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function () {
				if (this.readyState == 4 && this.status == 200) {
					console.log(this.responseText);
				}
			};

			let url = "sendsms.php";
			console.log(url);
			xhr.open('GET', url);
			xhr.send();
		});
	}



</script>

<div class="footer" style="margin-top:30px;">
			<footer><p><br>Copyright &copy;  Reserved By E-Care School</p></footer>
</div>
		