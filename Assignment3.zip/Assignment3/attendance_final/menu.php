<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>

        <title></title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <style type="text/css">

            body{
                 background-image: url('12.jpg');
	   background-position:center;
          background-size:cover;
          background-repeat: no-repeat;


            }
            *
            {
                padding: 0px;
                margin: 0px;
                box-sizing: border-box;
            }

            #scanlist{
                padding: 0px;
                margin: 0px;
                box-sizing: border-box;
            }

            .navbar1
            {
               width: 100%;
               padding: 10px;
               top: 0px;
               text-align: left;
               transition: .5s;
            }

            .navbar1 ul li{
                list-style-type: none;
                display: inline-block;
                padding: 10px 20px;
                color: white;
                font-size: 25px;
                font-family: sans-serif;
                cursor: pointer;
                border-radius: 10px;
                transition: .5s;
            }

            .navbar1 ul li:hover
            {
                background:white;
            }
            a:active{
                color: black;
            }



        </style>
    </head>
    <body>

        <br>

        <div class="navbar1">

                <ul>
                    <li>  <a href="adminpage.php">Home</a> </li>
                    <li>  <a href="add.php">Add New student</a>   </li>
                    <li>  <a href="academics.php">Add Academics</a>   </li>
                     <li> <a href="barcodescan.php">Scan Barcode</a>  </li>
                    <li>  <a href="logout.php">Logout</a></li>
                </ul>
        </div><br>



    </body>
</html>