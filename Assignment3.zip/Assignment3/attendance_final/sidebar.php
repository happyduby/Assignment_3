
<!doctype html>
<html>
    <head>
	   <title>home page</title>
	   <style>
	 a:link, a:visited {
  background-color:RebeccaPurple ;
  color: white;
  padding: 12px 20px;
  text-align: left;
  text-decoration: none;
  display: inline-block;
  border-radius: 10px;
}

a:hover, a:active {
  background-color: MediumOrchid;
 
}

	   </style>

	</head>
    <body>
	<div class="sidebar">


        &nbsp;&nbsp;&nbsp;<a href="admin.php">Admin Login</a><br><br>
	&nbsp;&nbsp;&nbsp;<a href="parent.php">Parent Login</a><br><br>
	
        &nbsp;&nbsp;&nbsp;<a href="index.php">Back-Start Page</a>
       <br>
</div
	</body>
</html>
		

