<?php
session_start();

include('navbar.php');
include ("3.php");

if ( isset($_SESSION['usname'])){
    include("display_attendance.php");
    echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
    include ("footer.php");
}
else{

    header("Location:parent.php");
}


?>

