<?php
session_start();
if(!isset($_SESSION["name"])){
    header("Location:admin.php");
}
?>
<html>
    <head>
        <style>
            .login-box 
            {
                font-size: 25px;
            }
           
             .login-box input[type="text"],input[type="password"]{
                border:none;
                border-bottom:  2px solid black;
                background: transparent;
                outline: none;
                height: 30px;
                color: purple;
                font-size: 16px;
                
            }
            .login-box input[type="submit"]
            {
                border: none;
                outline: none;
                height: 45px;
                width:140px;
                background:RebeccaPurple;
                color: wheat;
              font-weight: bold;
                font-size: 20px;
                border-radius: 10px;
                
                
            }
            .login-box input[type="submit"]:hover
            {
                cursor: pointer;
                background: mediumorchid;
                color:#000;
            }
          
            </style>
       
    </head>
<body>
    <?php
        // put your code here
include ('navbar.php');
        include ('menu.php');
        
?>
    
    <form action="addstudent.php" method="post"  enctype="multipart/form-data">
      <div class="login-box"><br>
<h2 align="center"> <B>STUDENT DETAILS</B></h2>

<fieldset>
    <legend><font color="purple" size="5"><b>Personal Details:</b></font></legend><br>
<p><strong>Roll No: <input type="text" name="roll" value="" size="25" maxlength="50"  placeholder="Enter Roll No" required><br></strong></p><br>
<p><strong>First Name: <input type="text" name="fname" value="" size="25" maxlength="50"  placeholder="Enter First Name" required><br></strong></p><br>
<p><strong>Last Name: <input type="text" name="lname" value="" size="25" maxlength="50"  placeholder="Enter Last Name" required><br></strong></p><br>
<p><strong>Mobile No:<input type="text" name="mobile" value="" size="25" maxlength="40"  placeholder="Enter Mobile No." required></strong></p><br>
<p>Profile:<input type="file" name="image" id="image"><br>
    <br>      
<p>Class:
<SELECT NAME="class">
<OPTION VALUE="1" SELECTED >Select An Option</OPTION>
<OPTION VALUE="First" >First</OPTION>
<OPTION VALUE="Second" >Second</OPTION>
<OPTION VALUE="Third" >Third</OPTION>
<OPTION VALUE="Fourth" >Fourth</OPTION>
</SELECT><br><br><strong>
</fieldset>
<br>



<fieldset>
    <legend><font color="purple" size="5"><b>Privacy :</b></font></legend><br>
<p><strong>Password : <input type="password" name="pass" value="" size="25" maxlength="55"  placeholder="Enter Password" required/>
<br></strong></p><br>



</fieldset>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="Post Details ">
</div>
</form>
      <?php
        // put your code here

        include ('footer.php');
        ?></body>
</html>