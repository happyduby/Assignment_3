<?php
    session_start();
    if(!isset($_SESSION["name"])){
        header("Location:admin.php");
    }
    include('navbar.php');
    include ("menu.php");
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        <!--In order to place the tracking correctly--> 
        canvas.drawing, canvas.drawingBuffer {
            position: absolute;
            left: 400px;
            top: 400px;
        }
    </style>
</head>

<body>
<!-- Div to show the scanner -->
<h2 align="center"> <B>BARCODE SCANNER</B></h2><br><hr>
<div id="scanner-container"></div>
<div style="padding-left:100px; background-color: green;color:white">
    <h3 style="color:black;padding-top: 20px;"><u>Instructions</u></h3><br>
    <ol style="padding-left: 20px;padding-bottom: 20px;!important;">
        <li>Click on the scanner button to start scanning.</li>
        <li>Allow permission for the site to use your webcam.</li>
        <li>Place the barcode to be scanned infront of the webcam.</li>
        <li>Wait till the message "Scanned Successfully" appears.</li>
        <li>Inorder to stop scanning, click on the scanner button again.</li>
    </ol>
</div>
<input  style="color: white;background-color: red; font-size:16px; padding: 15px 32px;display: block; margin: 0 auto; margin-top: 10px;" type="button" id="btn" value="Scanner" />

<!-- Include the image-diff library -->
<!-- -->
<div id="myModal" class="modal">

    <!-- Modal content -->
    <div class="modal-content">
        <p>Scanned Successfully</p>
    </div>

</div>

<script src="js/quagga.js"></script>

<script>
    var _scannerIsRunning = false;
    var modal = document.getElementById("myModal");
    var set = 0;
    var prev_code = "";



    

    function startScanner() {

        Quagga.init({numOfWorkers: 4, // no of cpu cores
            inputStream: {
                name: "Live",
                type: "LiveStream",
                target: document.querySelector('#scanner-container'), // where the scanning window will show
                constraints: {
                    width: 1000,
                    height: 1000,
                    facingMode: "environment"
                },
            },
            decoder: {
                patchSize: "xlarge",
                readers: [
                    "code_128_reader", // type of barcode encoding
                ],
                debug: {
                    showCanvas: true,
                    showPatches: true,
                    showFoundPatches: true,
                    showSkeleton: true,
                    showLabels: true,
                    showPatchLabels: true,
                    showRemainingPatchLabels: true,
                    boxFromPatches: {
                        showTransformed: true,
                        showTransformedBox: true,
                        showBB: true
                    }
                }
            },

        }, function (err) {
            if (err) {
                console.log(err);
                return
            }


            Quagga.start(); // starts the barcode scanner

            window.location.hash = '#scanner-container';

            let video = document.querySelector("#scanner-container > video");
            video.style.width = "100%";

            // Set flag to is running
            _scannerIsRunning = true;
        });

        Quagga.onProcessed(function (result) {

//            console.log("in process");
            var drawingCtx = Quagga.canvas.ctx.overlay,
                drawingCanvas = Quagga.canvas.dom.overlay;

            if (result) {
                if (result.boxes) {
                    drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
                    result.boxes.filter(function (box) {
                        return box !== result.box;
                    }).forEach(function (box) {
                        Quagga.ImageDebug.drawPath(box, { x: 0, y: 1 }, drawingCtx, { color: "green", lineWidth: 2 });
                    });
                }

                if (result.box) {
                    Quagga.ImageDebug.drawPath(result.box, { x: 0, y: 1 }, drawingCtx, { color: "#00F", lineWidth: 2 });
                }

                if (result.codeResult && result.codeResult.code) {
                    Quagga.ImageDebug.drawPath(result.line, { x: 'x', y: 'y' }, drawingCtx, { color: 'red', lineWidth: 3 });
                }
            }
        });

        function countInstances(string, word) {
            return string.split(word).length - 1;
        }


        Quagga.onDetected(function (result) {
            console.log("Barcode detected and processed : [" + result.codeResult.code + "]", result);

            // this if condition checks if barcode is fully scanned or not
            if(countInstances(result.codeResult.code, '#') >= 2)
            {
				let code =  result.codeResult.code;
                // this if condition checks has 2 condition
                // 1. it checks if a barcode is being scanned. If yes, it doesnt make another req to server
                // the prev_code checks if we have already scanned this bar_code
				if(set == 0 && (code != prev_code || prev_code == ""))
				{
					set = 1; 
	                console.log("Barcode detected and processed : [" + result.codeResult.code + "]", result);
	                let barcode = prev_code = result.codeResult.code;
                    // the below code removes # from start and end which are our markers
	                barcode = barcode.substring(1,barcode.length-1);
	                var xhr = new XMLHttpRequest();
	                xhr.onreadystatechange = function() {

	                
	                    if (this.readyState == 4) { // this checks if the request is complete

	                    	if(this.status == 200) // this checks if request is successful
	                    	{
		                    	console.log("success");
                                // the below code show successfully added
		                        modal.style.display = "block";
		                        setTimeout(function(){
                                    // this code removes the message successfully added
		                            modal.style.display = "none";
		                        },5000);
	                        }
	                        set = 0;
	                       
	                    }
	                };


	                let url ="mark_attendance.php?barcode="+barcode;
	                console.log(url);
	                xhr.open('GET', url);
	                xhr.send();
                    // the above code makes a request to this url for marking attendance
                }

            }else
            {
            	//console.log("Barcode detected and processed : [" + result.codeResult.code + "]", result);		
            }

        });
    }



    // Start/stop scanner
    document.getElementById("btn").addEventListener("click", function () {
        if (_scannerIsRunning) {
            Quagga.stop();
            _scannerIsRunning = false;
            document.querySelector('#scanner-container').innerHTML="";
        } else {
            startScanner();
        }
    }, false);
</script>
</body>

</html>
