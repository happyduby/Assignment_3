<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require('connection.php');


$date = date("Y-m-d")."\n";
$barcode = $_GET["barcode"];

try {
    // this marks the student as presnt by setting marked_date to today. tobe used for sms sending
    $query = "UPDATE student SET marked_date = '$date' WHERE barcodevalue= '$barcode';";
    if ($connection->query($query) === TRUE) {

        echo "Record updated successfully";
        // get the student info from scanned barcode
        $query = "SELECT * FROM student WHERE barcodevalue= '$barcode';";
        $result = mysqli_query( $connection,$query);

        if(mysqli_num_rows($result) == 1) {
            $record = mysqli_fetch_array($result);
            $roll_no = $record["rollno"];
            $markingdate = explode('-', date("Y-m-d"));
            $year = $markingdate[0];
            $month = $markingdate[1];

            if((int)$month < 6)
            {
                $old_year = $year-1;
                $academic_year = $old_year."-".$year;
            }else{
                $new_year = $year+1;
                $academic_year = $year."-".$new_year;
            }




            $day = $markingdate[2];
            // this is for keeping track of attendance month and yearwise
            $query = "INSERT INTO attendance_track (rollno,present,day,month,year,academic_year) VALUES ('$roll_no','yes','$day','$month','$year','$academic_year');";


            if ($connection->query($query) === TRUE) {

                echo "Record updated successfully";

            } else {

                echo "Error updating record: " . $connection->error;
            }
        }else
        {
            echo "Record not found";
        }




        } else {
        echo "Error updating record: " . $connection->error;
    }

}catch(Exception $e)
{
    echo "exception";
}

?>