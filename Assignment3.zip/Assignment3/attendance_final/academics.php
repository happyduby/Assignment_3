<?php
session_start();
if(!isset($_SESSION["name"])){
    header("Location:admin.php");
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>  <style>
            .login-box 
            {
                font-size: 25px;
            }
           
             .login-box input[type="text"],input[type="password"]{
                border:none;
                border-bottom:  2px solid black;
                background: transparent;
                outline: none;
                height: 30px;
                color: purple;
                font-size: 20px;
                
            }
            .login-box input[type="submit"]
            {
                border: none;
                outline: none;
                height: 45px;
                width:140px;
                background:RebeccaPurple;
                color: wheat;
              font-weight: bold;
                font-size: 20px;
                border-radius: 10px;
                
                
            }
            .login-box input[type="submit"]:hover
            {
                cursor: pointer;
                background: mediumorchid;
                color:#000;
            }
           
          
            </style>
    </head>
    <body>
      <?php
        // put your code here
include ('navbar.php');
        include ('menu.php');
     ?>
    <center><form action="addacademics.php" method="post" enctype="multipart/form-data"><br>
            <div class="login-box">
              Roll No.:    <input type="text" name="roll" required><br><br>
               Class:    <input type="text" name="class" required><br><br>
            Year:                
<SELECT NAME="year" required>
<OPTION VALUE="1" SELECTED >Select An Option</OPTION>
<OPTION VALUE="2018-19" >2018-19</OPTION>
<OPTION VALUE="2019-20" >2019-20</OPTION>
>
</SELECT><br><br>
              Examination:
<SELECT NAME="exam" required>
<OPTION VALUE="1" SELECTED >Select An Option</OPTION>
<OPTION VALUE="1st mid term" >1st mid term</OPTION>
<OPTION VALUE="1st term" >1st term</OPTION>
<OPTION VALUE="2nd mid term" >2nd mid term</OPTION>
<OPTION VALUE="2nd term" >2nd term</OPTION>
</SELECT><br><br>
          Result:<input type="file" name="image" id="image"><br><br>
      
        <input type="submit" name="submit"  value="submit">
            </div></form></center> 
        <?php
        // put your code here
include ('footer.php');
       
     ?>
        <
    </body>
</html>
