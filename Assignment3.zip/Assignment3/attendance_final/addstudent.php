<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
       
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
         session_start();// checks the start of the session
        require('connection.php');//db conn
        require 'vendor/autoload.php'; // for barcode generator, we use a library. This is how
        // you load libraries from vendor
        require 'functions.php';

        function barcodegenerator($roll_no,$class)
        {
                $Color = [0, 0, 0];
                $generator = new Picqer\Barcode\BarcodeGeneratorPNG(); // barcode generator class

            // saves barcode image  to a temporay file called temp.png
                file_put_contents('temp.png', $generator->getBarcode($class . $roll_no, $generator::TYPE_CODE_128, 2, 20, $Color));

                // then we merge the file with a white background image so that we can scan the barcode.
                image_merge($class . '_' . $roll_no);
        }




       
        if (isset($_POST['submit'])) // checks if form is submitted

        {
            $roll=$_POST['roll'];
            $fname=$_POST['fname'];
            $lname=$_POST['lname'];
            $num=$_POST['mobile'];
            $profile=$_FILES['image']['name'];
            $temp_profile=$_FILES['image']['tmp_name'];
            move_uploaded_file($temp_profile, "$profile");
            $class=$_POST['class'];
            $pwd=$_POST['pass'];

            $barcodevalue = "#".$class.$roll."#";
            barcodegenerator($roll,$class); // generates barcode based on rollno and class

             //step5 prepare the MySql Querry
            $query="insert into student(rollno,fname,lname,mnumber,profile,class,password,barcodevalue)values('$roll','$fname','$lname','$num','$profile','$class','$pwd','$barcodevalue');";

            //step 6:run the mysql query
            $result =  mysqli_query($connection,$query)
                    or die ("error in query: ".$query." ". mysqli_error($connection));
                if ($result) {
//                    echo"<h3>Successfully Added</h3>";
                    //echo '<div class="successalert"><span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span>Successfully Added</div> ';
                    header("Location:adminpage.php?success=1");

                }
                else
                    echo"Error in Adding";
            }
        ?>
    </body>
</html>
