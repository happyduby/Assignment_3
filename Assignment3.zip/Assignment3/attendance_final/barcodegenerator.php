<?php
require 'vendor/autoload.php';

$redColor = [0, 0, 0];

$generator = new Picqer\Barcode\BarcodeGeneratorPNG();

try {
    file_put_contents('barcode.png', $generator->getBarcode('#First2016-991#', $generator::TYPE_CODE_128, 2, 20, $redColor));
}catch (Exception $e)
{
    echo $e;
}
?>