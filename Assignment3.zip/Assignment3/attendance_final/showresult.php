<?php
session_start();
require ("connection.php");
?>


<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <style>
            .backbutton:link, .backbutton:visited {
                background-color:RebeccaPurple ;
                color: white;
                padding: 12px 20px;
                text-align: left;
                text-decoration: none;
                display: inline-block;
                border-radius: 10px;
            }

            .backbutton:hover, .backbutton:active {
                background-color: MediumOrchid;

            }
        </style>
    </head>
    
    <body>
<?php

$roll=$_SESSION['roll'];
$year=$_GET['year'];
$exam=$_GET['exam'];





$query="select result from academics where  year='$year' and exam='$exam' AND rollno = '$roll';";
 $result =  mysqli_query($connection,$query)
                or die ("error in query: ".$query." ". mysqli_error($connection));
     $row= mysqli_fetch_array($result);


$result = "NA";
if(!empty($row["result"]))
    $result = $row["result"];


include ('navbar.php');
        include ('3.php');


//$image_path = "mark/".$roll."/".$result;
$image_path = "marks/".$year."/".$roll."/".$exam."/".$result;
if (file_exists($image_path)) {
    echo "<center><img src='{$image_path}' height='130%' width='50%'/></center>";
} else {

    echo '<div class="alert"><span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span>Result not available for this academic year and exam </div>';

}




?>

<a class="backbutton" href="parentpage.php">Back-Home Page</a>
    </body>
</html>