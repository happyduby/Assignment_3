<html>
	<head>
		<title>E-Care School</title>
		<link rel="stylesheet" type="text/css" href="style.css">
                 <style>
                    body{
                        
                    background:linear-gradient(to bottom right,skyblue,violet,skyblue);}
                </style>
	</head>
	<body>
	<?php include"navbar.php";?>
		
          
		
        <center>  <img src="1_1.jpg"  class="sha"></center>
			
			<div id="section">
			
				<?php include"sidebar.php";?><br>
				
				<div class="content">
					<h1 class="text">Welcome </h1><br><hr><br>
						<h3 align="center"> School Information</h3>
					<img src="home.jpg" class="imgs">
					<p class="para">
						E-Care School is a complete school management website designed for the security of the students.
					
					
						This software has a powerful online community to bring parents, teachers and students on a common interactive platform. It is a paperless work solution for today's modern schools. It provides the facility to show the academics of their kids plus it also let the parents know if their student have come to school or not. .
					</p>
				</div>
				
			</div>
	
		<?php include"footer.php";?>
	</body>
</html