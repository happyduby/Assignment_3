<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <style type="text/css">
            body{
                 background-image: url('14.jpg');
	   background-position:center;
          background-size:cover; 
          background-repeat: no-repeat;
          
          
            }
            *
            {
                padding: 0px;
                margin: 0px;
                box-sizing: border-box;
            }
            
            .navbar1
            {
               width: 100%;
               padding: 10px;
               top: 0px;
               text-align: left;
               transition: .5s;              
            }
            .navbar1 ul li{
                list-style-type: none;
                display: inline-block;
                padding: 10px 20px;
                color: white;
                font-size: 20pt;
                font-family: sans-serif;
                cursor: pointer;    
                border-radius: 10px;
                transition: .5s;
            }
            .navbar1 ul li:hover
            {
                background:white;
            }
          
            
           
            
        </style>
    </head>
    <body>
        
        <br><br>
        <h1 align="center">STUDENT DETAILS</h1>
        
        <div class="navbar1">
                
                <ul>   
                    <li>  <a href="parentpage.php">Home</a> </li>
                   <li>  <a href="result.php">Result</a> </li>
                   <li>  <a href="attendance.php">Attendance</a> </li>
                    <li>  <a href="logout.php">Logout</a></li>
                </ul>
        </div>
        <hr>
      
    </body>
</html>