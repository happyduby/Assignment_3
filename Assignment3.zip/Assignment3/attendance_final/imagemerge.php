<?php

try {
    $photo_to_paste = "barcode.png";  //image 321 x 400
    $white_image = "bgwhite.png"; //873 x 622

    $im = imagecreatefrompng($white_image);
    $condicion = GetImageSize($photo_to_paste); // image format?


    $im2 = imagecreatefrompng($photo_to_paste);


    imagecopy($im, $im2, (imagesx($im) / 2) - (imagesx($im2) / 2), (imagesy($im) / 2) - (imagesy($im2) / 2), 0, 0, imagesx($im2), imagesy($im2));

    imagejpeg($im, "test4.jpg", 90);
    imagedestroy($im);
    imagedestroy($im2);
}catch(Exception $e)
{
    echo $e->getMessage();
}

?>