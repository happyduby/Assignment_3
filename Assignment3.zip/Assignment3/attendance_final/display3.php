<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <style type="text/css">
       
        table{
            width: 1200px;
            margin: auto;
            text-align: center;
            table-layout: fixed;     
        }
        table,tr, th,td{
            padding: 7px;
            color:white;
            border:4px solid black;
            font-size: 13px;
            border-collapse: collapse;
            font-family: arial;
            background:palevioletred;  
        }
        td:hover{
            background:orange;
        }
    </style>
    <body>
<?php

require ("connection.php");

$roll=$_SESSION['roll'];
//$pwd=$_POST['pass'];
  

$query="select rollno,fname,lname,class,profile from student where rollno='$roll'";// and password='$pwd';";
 $result =  mysqli_query($connection,$query)
                or die ("error in query: ".$query." ". mysqli_error($connection));
     $row= mysqli_fetch_array($result);

       echo"<br><BR><table><tr><th>Profile</th><th> Roll No</th><th>First Name</th><th>Last Name</th><th>Class</th></tr>";


     
 echo "<tr><td><img src='{$row["profile"]}' height='70' width='70'></td><td>".$row['rollno'].
      "</td><td> ".$row['fname'].
         
          "</td><td> ".$row['lname'].
      "</td>
          <td>".$row['class'].
      "</td>
          </tr>";
     
      echo"</table>";

 

     
    
     
?>
    </body>
</html>