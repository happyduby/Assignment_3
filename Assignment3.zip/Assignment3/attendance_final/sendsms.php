<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

require 'connection.php';
require 'functions.php';

$date = date("Y-m-d")."\n";

// All those students who are not marked for today will get sms
$query = "SELECT * FROM student WHERE marked_date < '$date' OR marked_date is NULL";

$result = mysqli_query( $connection,$query)or die ("Error in query: ".$query. " ".mysqli_error($connection));

if (mysqli_num_rows($result) > 0) {

    while($row = mysqli_fetch_assoc($result))
    {
        $rollno = $row["rollno"];
        $date = explode('-', date("Y-m-d"));
        $year = $date[0];
        $month = $date[1];
        $day = $date[2];

        if((int)$month < 6)
        {
            $old_year = $year-1;
            $academic_year = $old_year."-".$year;
        }else{
            $new_year = $year+1;
            $academic_year = $year."-".$new_year;
        }


        // we keep a track of students absent record

        $query = "INSERT INTO  attendance_track VALUES (NULL,'$rollno','no',$day,$month,$year,'$academic_year')";
        $connection->query($query);
        sendSMS($row);
    }

}else
{
    echo "no students";
}








?>