<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <style type="text/css">
            body{
                margin:0;
                padding:0;
               font-family:blue;
            
 background:linear-gradient(to bottom right,skyblue,violet,skyblue);
                  
            }
            .login-box
            {
                width:420px;
                height: 418px;
                color:black;
                top:75%;
                left: 50%;
                position: absolute;
                transform: translate(-50%,-50%);
                box-sizing: border-box;
                background:linear-gradient(to bottom right,blue,violet,skyblue);
                               padding: 100px 30px;
                font-size: 18pt;
                opacity: 1;
                
            }
            .userlogin{
                width: 100px;
                height: 100px;
                border-radius: 50%;
                position:  absolute ;
            top: -50px;
            left: calc(34%);
           
                
            }
            
            h1{
                margin: 0;
                padding: 0 0 10px;
                font-size: 22px;
            }
            .login-box p{
                margin: 0;
                padding: 0;
                font-weight: bold;
                 font-size: 25px;
            }
            .login-box input
            {
               width: 100%;
               margin-bottom: 20px;
               
            }
            .login-box input[type="text"],input[type="password"]{
                border:none;
                border-bottom:  1px solid black;
                background: transparent;
                outline: none;
                height: 50px;
                color:black;
                font-size: 20px;
            }
            .login-box input[type="submit"]
            {
                border: none;
                outline: none;
                height: 35px;
                background: #80aaff;
                color: wheat;
                font-size: 18px;
                border-radius: 10px;
                 font-size: 25px;
                 
                 
                
                
            }
            .login-box input[type="submit"]:hover
            {
                cursor: pointer;
                background: greenyellow;
                color:#000;
            }
          
             a:link, a:visited {
  background-color:#80aaff ;
  color: white;
  padding: 20px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  border-radius: 10px;
  font-size:30px;
}
a:hover, a:active {
  background-color:greenyellow;
            }
            
            
            
            </style>
    </head>
    <body>
         
        <?php include"navbar.php";
      
				
			
         ?>
    <center> <img src="15.jpg" width="1790px" height="300px" ></center>
       
        <div class="login-box">
           
            <img src="Family_care-512.png"  class="userlogin">
           
        
            
            <H3 align="center"><font color="black" face="Algerian">PARENT LOGIN</font></H3>
            <form action=parentpage.php method="post">
            
          
            <p> Roll No.</p> <input type="text" name="roll"  placeholder="Enter Roll No." required >
             <p> Password </p> <input type="password" name="pass" placeholder="Enter Password" required>
       
            <input type="submit" name="login" value="Login"> <br>
            </form></div>
           <div align="right">
            <br><BR><a  href="home.php">Back </a>&nbsp; &nbsp;&nbsp;&nbsp;   <br><br>
		</div>	
           
           
           
   <br><br> <br><br><br><br><br><br><br><br><br><br><br><br><br>


               
  <?php include"footer.php";?>
              
    </body>
</html>