<?php
//session_start();
//if(!isset($_SESSION["name"])){
//    header("Location:admin.php");
//}
?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
       
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
         session_start(); // checks the start of the session
        require('connection.php'); //db conn
        if (isset($_POST['submit'])) // checks if form is submitted
        {

        $roll=$_POST['roll'];
        $class=$_POST['class'];
        $year=$_POST['year'];
        $exam=$_POST['exam'];
        $marks=$_FILES['image']['name'];
        $temp_marks=$_FILES['image']['tmp_name'];
        move_uploaded_file($temp_marks, "$marks");  // for uploading marks as a file
 




             //step5 prepare the MySql Querry
        $query="insert into academics(rollno,class,year,exam,result)values('$roll','$class','$year','$exam','$marks');";

        //step 6:run the mysql query
        $result =  mysqli_query($connection,$query)
                or die ("error in query: ".$query." ". mysqli_error($connection));
            if ($result) {
                echo '<div class="successalert"><span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span>Successfully Added</div> ';
                include("adminpage.php");

            }
            else
                echo '<div class="alert"><span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span>Error in Adding</div> ';
        }
        ?>
    </body>
</html>
