<?php

session_start();


if ( isset($_POST['name']))
{
require("connection.php");
$name=$_POST['name'];
$pwd=$_POST['pass'];

$query = "SELECT * FROM incharge WHERE username='$name'  AND password='$pwd'; ";
$result = mysqli_query( $connection,$query)or die ("Error in query: ".$query. " ".mysqli_error($connection));

if (mysqli_num_rows($result) > 0) {
 $_SESSION['name']=$_POST['name'];
 mysqli_free_result($result);
 mysqli_close($connection);
include('navbar.php');
 include ("menu.php");
    echo '<button id="sms" style=" margin-left:60px;background-color: red; font-size:16px; padding: 15px 32px;"> Send Attendance SMS</button>';
 include ("display.php");
  echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
 include ("footer.php");


}
else
{
    mysqli_free_result($result);
    mysqli_close($connection);

//    echo '<div class="alert"><span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span>Invalid Login</div> ';



//    echo "<h1 align='center'><font color='white'>Invalid Login</font></h1>";
    include ("admin.php");

    echo '  <script>

               window.onload = function(e)
               {

                   alert("Invalid Login");
               }

           </script>';



    exit();
}
}
else if(isset($_SESSION["name"])){ // this page is if the incharge is already logged in
    
include('navbar.php');
 include ("menu.php");
 ?>

    <button id="sms" style=" margin-left:60px;background-color: red; font-size:16px; padding: 15px 32px;"> Send Attendance SMS</button>

<?php
 include ("display.php");
 echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
 ?>




 <?php
 include ("footer.php");
    // this code checks if user added a student. If yes, it shows a msg.
    //$newadd = $_GET["success"];
	?>
<script>
var newadd = <?php echo $newadd;?>;
if(newadd) {
    window.onload = function (e) {
        alert("Student Succcessfully added");
    }
}
</script>;

<?php
 }
else{
    header("Location:admin.php");
}
        ?>
