<html>
    <head></head>
    <body>
        <div class="navbar">

			<ul class="list">
                           
				<b style="color:white;float:center;line-height:50px;font-family:Cooper Black;
                                   font-size:30px; font-family:Algerian;">
				E-CARE SCHOOL</b>
				
			</ul>
		</div>
		
        
        
    </body></html>


