<?php

if(!isset($_SESSION))
{
    session_start();
}

if ( !isset($_SESSION['usname'])){
    require("connection.php");
    $roll=$_POST['roll'];
    $pwd=$_POST['pass'];

    $query = "SELECT * FROM student WHERE rollno='$roll'  AND password='$pwd'; ";
    $result = mysqli_query( $connection,$query)or die ("Error in query: ".$query. " ".mysqli_error($connection));

    if (mysqli_num_rows($result) > 0) {
        $_SESSION['usname']=$_POST['roll'];
        $_SESSION['roll']=$_POST['roll'];
        mysqli_free_result($result);
        mysqli_close($connection);
        include('navbar.php');
        include ("3.php");
        include ("display3.php");
        echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
        include ("footer.php");

    }
    else
    {
        mysqli_free_result($result);
        mysqli_close($connection);
//    echo "<br><br><br><br><br><br><br><br><br>";


//    echo "<h3 align='center'><font color='white'>Invalid Login</font></h3>";
        include ("parent.php");

        echo '  <script>

               window.onload = function(e)
               {

                   alert("Invalid Login");
               }

           </script>';

        exit();
    }
}
else{
    include('navbar.php');
    include ("3.php");
    include ("display3.php");
    echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";

    include ("footer.php");

}


?>

