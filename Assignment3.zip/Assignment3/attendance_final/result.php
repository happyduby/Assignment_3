<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>  <style>
            .login-box 
            {
                font-size: 25px;
            }
           
             .login-box input[type="text"]{
                border:none;
                border-bottom:  2px solid black;
                background: transparent;
                outline: none;
                height: 30px;
                color: purple;
                font-size: 20px;
                
            }
            .login-box input[type="submit"]
            {
                border: none;
                outline: none;
                height: 45px;
                width:140px;
                background:RebeccaPurple;
                color: wheat;
              font-weight: bold;
                font-size: 20px;
                border-radius: 10px;
                
                
            }
            .login-box input[type="submit"]:hover
            {
                cursor: pointer;
                background: mediumorchid;
                color:#000;
            }
            .dropdown{
                position: relative;
                display: inline-block;
            }
       
            </style>
    </head>
    <body>
      <?php
        // put your code here
include ('navbar.php');
        include ('3.php');
     ?>
    <center><form action="showresult.php" method="GET"><br>
            <div class="login-box">
            
       <div class="dropdown">     Year:                
<SELECT NAME="year" required>
<OPTION VALUE="1" SELECTED >Select Academic Year</OPTION>
<OPTION VALUE="2018-19" >2018-19</OPTION>
<OPTION VALUE="2019-20" >2019-20</OPTION>
>
</SELECT><br><br>
              Examination:
<SELECT NAME="exam" required>
<OPTION VALUE="1" SELECTED >Select Examination </OPTION>
<OPTION VALUE="1st mid term" >1st mid term</OPTION>
<OPTION VALUE="1st term" >1st term</OPTION>
<OPTION VALUE="2nd mid term" >2nd mid term</OPTION>
<OPTION VALUE="2nd term" >2nd term</OPTION>
</SELECT><br><br><br><br>
       </div> 
      
        <input type="submit" name="submit"  value="submit">
            </div></form></center> 
        <?php
        // put your code here
include ('footer.php');
       
     ?>

    </body>
</html>
