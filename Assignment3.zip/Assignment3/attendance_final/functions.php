<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



function image_merge($image_name)
{
    // this function is for merging the barcode generated image onto a white image
    // so that scanning is possible
    $photo_to_paste = "temp.png";  //image 321 x 400
    $white_image = "bgwhite.png"; //873 x 622
    $im = imagecreatefrompng($white_image);
    $condicion = GetImageSize($photo_to_paste); // image format?
    $im2 = imagecreatefrompng($photo_to_paste);
    imagecopy($im, $im2, (imagesx($im) / 2) - (imagesx($im2) / 2), (imagesy($im) / 2) - (imagesy($im2) / 2), 0, 0, imagesx($im2), imagesy($im2));

    imagejpeg($im, "barcode_images/".$image_name.".jpg", 90);
    imagedestroy($im);
    imagedestroy($im2);
}


function sendSMS($details)
{
    	// Account details
    	//$apiKey = urlencode('3AifooBrQ0E-2lHcICccHb7lxR5dcLKdlGZoipyPIs');
    //  user id for textlocal sms service
    	//$apiKey = urlencode('CsxbyTBUycA-Pv1TzkU4uP2VzEpwOwPdutk5iGB7xZ');
$apiKey = urlencode('NjY2NjQ3Mzg1NTcwNGI0YzUzMzczMjQ5NDMzNzU0NjQ=');
    	// Message details
    	$numbers = array($details["mnumber"]);
    	$sender = urlencode("TXTLCL"); // sender name that will appear on msg
        $fname = $details['fname'];
        $lname = $details['lname'];
        $date = date("Y-m-d")."\n";

        $msg = "Hi Parents of $fname $lname, %n We would like to inform you that your child was absent today i.e. $date %n SCHOOL";


    	$message = rawurlencode($msg);

    	$numbers = implode(',', $numbers);


    	// Prepare data for POST request
    	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);


    	 //Send the POST request to textlocal with cURL which will send the msg
    	$ch = curl_init('https://api.textlocal.in/send/');
    	curl_setopt($ch, CURLOPT_POST, true);
    	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	$response = curl_exec($ch);
    	curl_close($ch);

    	// Process your response here

}


?>