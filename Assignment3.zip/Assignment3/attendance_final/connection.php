<?php


$servername="localhost";
$username="root";
$password="";
$db="school1";


$connection = mysqli_connect($servername,$username,$password,$db);
if (!$connection)
{
    die ('Could not connect: '.mysql_error());

//step 3: select database
    $database="school1";
mysql_select_db($database,$connection);
   
   
}
?>